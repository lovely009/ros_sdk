nmea_msgs
=========

This package contains message definitions for working with NMEA data.

Please see the ROS Wiki: http://wiki.ros.org/nmea_msgs
